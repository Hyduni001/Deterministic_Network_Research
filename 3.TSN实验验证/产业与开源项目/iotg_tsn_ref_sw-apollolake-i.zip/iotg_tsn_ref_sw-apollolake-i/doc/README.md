# User Guide
This documentation is written based on an Intel® Atom Processor E3900 (Apollo
Lake) platform where the dependencies for TSN Reference Software for Linux are
included within its Board Support Package (BSP). Further information can be
found in this User Guide.

To view this documentation:
1. Download and unzip the zip file.
2. Open TSN_UG_index.htm with Google Chrome or Internet Explorer.

Tip: You can also download a PDF version for your convenience by going to the
     Download PDF topic located in the left navigation bar of TSN_UG_index.htm.

