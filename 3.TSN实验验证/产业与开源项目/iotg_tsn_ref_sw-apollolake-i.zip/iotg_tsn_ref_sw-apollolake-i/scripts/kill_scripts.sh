pkill simple_talker-cmsg
killall sample-app-taprio
pkill simple_listener
pkill tcpdump
pkill mrpd
pkill ptp4l
pkill phc2sys
pkill iperf3

